package com.example.wellness;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class PeriodMonitoringActivity extends AppCompatActivity {

    private DBHelper dbHelper; // Declare DBHelper instance
    private EditText etStartDate, etCycleLength; // Declare period input fields
    private Button btnAddPeriod; // Declare buttons
    private long userId; // Variable to store user ID

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_period_monitoring); // Ensure this layout has your buttons and EditTexts

        dbHelper = new DBHelper(this); // Initialize the DBHelper instance

        // Initialize period input fields
        etStartDate = findViewById(R.id.etStartDate);
        etCycleLength = findViewById(R.id.etCycleLength);
        btnAddPeriod = findViewById(R.id.iconAddPeriod);

        // Retrieve the user ID passed as an extra
        userId = getIntent().getLongExtra("USER_ID", -1); // Make sure to set a valid ID

        btnAddPeriod.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                addPeriod(); // Call the method to add a period
            }
        });
    }

    private void addPeriod() {
        String startDate = etStartDate.getText().toString().trim();
        String cycleLengthStr = etCycleLength.getText().toString().trim();

        // Validate input
        if (startDate.isEmpty() || cycleLengthStr.isEmpty()) {
            Toast.makeText(this, "Please fill all fields", Toast.LENGTH_SHORT).show();
            return;
        }

        int cycleLength;
        try {
            cycleLength = Integer.parseInt(cycleLengthStr); // Parse cycle length from string
        } catch (NumberFormatException e) {
            Toast.makeText(this, "Invalid cycle length.", Toast.LENGTH_SHORT).show();
            return;
        }

        long id = dbHelper.insertPeriod(userId, startDate, cycleLength); // Use the instance method with userId
        if (id > 0) {
            Toast.makeText(this, "Period added successfully!", Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(this, "Failed to add period.", Toast.LENGTH_SHORT).show();
        }
    }
}
