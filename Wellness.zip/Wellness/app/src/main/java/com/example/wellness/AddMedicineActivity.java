package com.example.wellness;

import android.app.AlarmManager;
import android.app.DatePickerDialog;
import android.app.PendingIntent;
import android.app.TimePickerDialog;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.Locale;

public class AddMedicineActivity extends AppCompatActivity {

    private static final String TAG = "AddMedicineActivity";
    private EditText editTextMedicineName, editTextPurpose, editTextDate, editTextTime, editTextExpiration, etCustomFrequency;
    private Spinner spinnerFrequency;
    private CheckBox checkBoxEveryday;
    private Button btnAddMedicine;
    private List<CheckBox> dayCheckBoxes;
    private DBHelper dbHelper;
    private long currentUserId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_medicine);

        // Initialize UI elements
        editTextMedicineName = findViewById(R.id.editTextMedicineName);
        editTextPurpose = findViewById(R.id.editTextPurpose);
        editTextDate = findViewById(R.id.editTextDate);
        editTextTime = findViewById(R.id.editTextTime);
        editTextExpiration = findViewById(R.id.editTextExpiration);
        etCustomFrequency = findViewById(R.id.etCustomFrequency);
        spinnerFrequency = findViewById(R.id.spinnerFrequency);
        checkBoxEveryday = findViewById(R.id.checkBoxEveryday);
        btnAddMedicine = findViewById(R.id.iconAddMedicine);

        dbHelper = new DBHelper(this);
        currentUserId = getSharedPreferences("user_session", MODE_PRIVATE).getLong("user_id", -1);

        if (currentUserId == -1) {
            Toast.makeText(this, "User not logged in", Toast.LENGTH_SHORT).show();
            finish();
            return;
        }

        // Setup the frequency spinner and initialize UI behavior
        setupFrequencySpinner();

        // Setup checkboxes for selecting days of the week
        setupDayCheckboxes();

        // Show date and time pickers when the corresponding fields are clicked
        editTextDate.setOnClickListener(v -> showDatePicker(editTextDate));
        editTextTime.setOnClickListener(v -> showTimePicker(editTextTime));
        editTextExpiration.setOnClickListener(v -> showDatePicker(editTextExpiration));

        // Add medicine to the database and schedule alarms when the button is clicked
        btnAddMedicine.setOnClickListener(v -> addMedicine());
    }

    // Sets up the frequency spinner with predefined options and handles the "Custom" frequency input
    private void setupFrequencySpinner() {
        String[] frequencyOptions = {"1 Hour", "2 Hours", "4 Hours", "6 Hours", "Custom"};
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, frequencyOptions);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerFrequency.setAdapter(adapter);

        spinnerFrequency.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                String selectedFrequency = (String) parent.getItemAtPosition(position);
                if (selectedFrequency.equals("Custom")) {
                    etCustomFrequency.setVisibility(View.VISIBLE);
                } else {
                    etCustomFrequency.setVisibility(View.GONE);
                    etCustomFrequency.setText("");
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {}
        });
    }

    // Sets up checkboxes for days of the week and enables/disables them based on the "Everyday" checkbox
    private void setupDayCheckboxes() {
        dayCheckBoxes = new ArrayList<>();
        int[] dayIds = {R.id.checkBoxMonday, R.id.checkBoxTuesday, R.id.checkBoxWednesday, R.id.checkBoxThursday, R.id.checkBoxFriday, R.id.checkBoxSaturday, R.id.checkBoxSunday};

        for (int dayId : dayIds) {
            CheckBox checkBox = findViewById(dayId);
            dayCheckBoxes.add(checkBox);
        }

        checkBoxEveryday.setOnCheckedChangeListener((buttonView, isChecked) -> {
            for (CheckBox dayCheckBox : dayCheckBoxes) {
                dayCheckBox.setEnabled(!isChecked);
            }
        });
    }

    // Adds a new medicine entry to the database and schedules the associated alarms
    private void addMedicine() {
        String medicineName = editTextMedicineName.getText().toString().trim();
        String purpose = editTextPurpose.getText().toString().trim();
        String date = editTextDate.getText().toString().trim();
        String time = editTextTime.getText().toString().trim();
        String expiration = editTextExpiration.getText().toString().trim();

        if (medicineName.isEmpty() || purpose.isEmpty() || date.isEmpty() || time.isEmpty() || expiration.isEmpty()) {
            Toast.makeText(this, "Please fill in all fields", Toast.LENGTH_SHORT).show();
            return;
        }

        long result = dbHelper.insertMedicine(currentUserId, medicineName, purpose, date, time, expiration, "", checkBoxEveryday.isChecked(), getFrequencyHours());
        if (result != -1) {
            Toast.makeText(this, "Medicine added successfully", Toast.LENGTH_SHORT).show();
            setMedicineAlarm(medicineName, purpose, expiration, time);
            setExpirationAlarm(medicineName, expiration);
            finish();
        } else {
            Toast.makeText(this, "Failed to add medicine", Toast.LENGTH_SHORT).show();
        }
    }

    // Retrieves the frequency in hours based on the spinner or custom input
    private int getFrequencyHours() {
        if ("Custom".equals(spinnerFrequency.getSelectedItem().toString())) {
            return Integer.parseInt(etCustomFrequency.getText().toString().trim());
        }
        return Integer.parseInt(spinnerFrequency.getSelectedItem().toString().split(" ")[0]);
    }

    // Schedules medicine reminders based on selected days, start time, and frequency
    private void setMedicineAlarm(String medicineName, String purpose, String expiration, String time) {
        AlarmManager alarmManager = (AlarmManager) getSystemService(ALARM_SERVICE);
        String[] timeParts = time.split(":");
        int startHour = Integer.parseInt(timeParts[0]);
        int startMinute = Integer.parseInt(timeParts[1]);
        int frequencyHours = getFrequencyHours();

        // Loop through all days of the week
        for (int i = 0; i < 7; i++) {
            CheckBox dayCheckBox = dayCheckBoxes.get(i);

            // Skip unselected days unless "Everyday" is checked
            if (!checkBoxEveryday.isChecked() && !dayCheckBox.isChecked()) {
                continue;
            }

            int dayOfWeek = Calendar.SUNDAY + i; // Calendar.SUNDAY = 1
            Calendar calendar = Calendar.getInstance();
            calendar.set(Calendar.DAY_OF_WEEK, dayOfWeek);
            calendar.set(Calendar.HOUR_OF_DAY, startHour);
            calendar.set(Calendar.MINUTE, startMinute);
            calendar.set(Calendar.SECOND, 0);

            Intent intent = new Intent(this, AlarmReceiver.class);
            intent.putExtra("medicineName", medicineName);
            intent.putExtra("purpose", purpose);
            intent.putExtra("expiration", expiration);
            intent.putExtra("type", "medicine_reminder");

            if (frequencyHours > 0) {
                // Schedule multiple alarms within a day based on frequency
                for (int offset = 0; offset < 24 / frequencyHours; offset++) {
                    Calendar alarmCalendar = (Calendar) calendar.clone();
                    alarmCalendar.add(Calendar.HOUR_OF_DAY, offset * frequencyHours);

                    // Prepare intent and unique request code for each alarm
                    int requestCode = medicineName.hashCode() + (i * 100) + offset; // Ensure uniqueness
                    PendingIntent pendingIntent = PendingIntent.getBroadcast(
                            this, requestCode, intent, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

                    if (alarmManager != null) {
                        alarmManager.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, alarmCalendar.getTimeInMillis(), pendingIntent);
                    }
                }
            } else {
                // Single alarm for the day
                int requestCode = medicineName.hashCode() + i; // Ensure uniqueness
                PendingIntent pendingIntent = PendingIntent.getBroadcast(
                        this, requestCode, intent, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

                if (alarmManager != null) {
                    alarmManager.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, calendar.getTimeInMillis(), pendingIntent);
                }
            }
        }
    }

    // Schedules an alarm for when the medicine expires
    private void setExpirationAlarm(String medicineName, String expirationDate) {
        AlarmManager alarmManager = (AlarmManager) getSystemService(ALARM_SERVICE);
        Intent intent = new Intent(this, AlarmReceiver.class);
        intent.putExtra("medicineName", medicineName);
        intent.putExtra("type", "expiration_reminder");
        intent.putExtra("expiration", expirationDate);

        String[] dateParts = expirationDate.split("-");
        Calendar calendar = Calendar.getInstance();
        calendar.set(Calendar.YEAR, Integer.parseInt(dateParts[0]));
        calendar.set(Calendar.MONTH, Integer.parseInt(dateParts[1]) - 1); // Month is 0-indexed
        calendar.set(Calendar.DAY_OF_MONTH, Integer.parseInt(dateParts[2]));
        calendar.set(Calendar.HOUR_OF_DAY, 0);
        calendar.set(Calendar.MINUTE, 0);
        calendar.set(Calendar.SECOND, 0);

        PendingIntent pendingIntent = PendingIntent.getBroadcast(
                this, (medicineName + "_expiration").hashCode(), intent, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

        if (alarmManager != null) {
            alarmManager.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, calendar.getTimeInMillis(), pendingIntent);
        }
    }

    // Displays a date picker dialog and sets the selected date in the corresponding field
    private void showDatePicker(final EditText dateField) {
        final Calendar calendar = Calendar.getInstance();
        int year = calendar.get(Calendar.YEAR);
        int month = calendar.get(Calendar.MONTH);
        int day = calendar.get(Calendar.DAY_OF_MONTH);

        DatePickerDialog datePickerDialog = new DatePickerDialog(this, (view, selectedYear, selectedMonth, selectedDay) -> {
            String selectedDate = String.format(Locale.getDefault(), "%04d-%02d-%02d", selectedYear, selectedMonth + 1, selectedDay);
            dateField.setText(selectedDate);
        }, year, month, day);
        datePickerDialog.show();
    }

    // Displays a time picker dialog and sets the selected time in the corresponding field
    private void showTimePicker(final EditText timeField) {
        final Calendar calendar = Calendar.getInstance();
        int hour = calendar.get(Calendar.HOUR_OF_DAY);
        int minute = calendar.get(Calendar.MINUTE);

        TimePickerDialog timePickerDialog = new TimePickerDialog(this, (view, selectedHour, selectedMinute) -> {
            String selectedTime = String.format(Locale.getDefault(), "%02d:%02d", selectedHour, selectedMinute);
            timeField.setText(selectedTime);
        }, hour, minute, true);
        timePickerDialog.show();
    }
}
