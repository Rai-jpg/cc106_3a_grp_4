package com.example.wellness;

import android.app.AlarmManager;
import android.app.DatePickerDialog;
import android.app.PendingIntent;
import android.app.TimePickerDialog;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.Locale;

public class MedicineReminderActivity extends AppCompatActivity {

    private EditText etMedicineName, etPurpose, etDate, etTime, etExpiration, etCustomFrequency;
    private Spinner spinnerDaysToTake, spinnerFrequency;
    private Button btnSetReminder;
    private DBHelper databaseHelper;

    // Assuming you have a method to get the current user's ID
    private long currentUserId = 1; // Replace with your actual user ID retrieval logic
    private List<String> selectedDays; // To store selected days

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_medicine_reminder);

        etMedicineName = findViewById(R.id.etMedicineName);
        etPurpose = findViewById(R.id.etPurpose);
        etDate = findViewById(R.id.etDate);
        etTime = findViewById(R.id.etTime);
        etExpiration = findViewById(R.id.etExpiration);
        etCustomFrequency = findViewById(R.id.etCustomFrequency);
        spinnerFrequency = findViewById(R.id.spinnerFrequency);
        btnSetReminder = findViewById(R.id.btnSetReminder);
        databaseHelper = new DBHelper(this);

        // Setup Spinner for Days
        setupDaysSpinner();
        // Setup Spinner for Frequency
        setupFrequencySpinner();

        btnSetReminder.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                setMedicineReminder();
            }
        });
    }

    private void setupDaysSpinner() {
        String[] daysArray = {"Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"};
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, daysArray);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerDaysToTake.setAdapter(adapter);

        selectedDays = new ArrayList<>();

        spinnerDaysToTake.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                String selectedDay = (String) parent.getItemAtPosition(position);
                if (!selectedDays.contains(selectedDay)) {
                    selectedDays.add(selectedDay);
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
                // Do nothing
            }
        });
    }

    private void setupFrequencySpinner() {
        String[] frequencyOptions = {"1 Hour", "2 Hours", "4 Hours", "6 Hours", "Custom"};
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, frequencyOptions);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerFrequency.setAdapter(adapter);

        spinnerFrequency.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                String selectedFrequency = (String) parent.getItemAtPosition(position);
                if (selectedFrequency.equals("Custom")) {
                    etCustomFrequency.setVisibility(View.VISIBLE); // Show custom frequency input
                } else {
                    etCustomFrequency.setVisibility(View.GONE); // Hide custom frequency input
                    // Set the custom frequency to empty when a predefined option is selected
                    etCustomFrequency.setText("");
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
                // Do nothing
            }
        });
    }
    private void showDatePicker(final EditText dateField) {
        final Calendar calendar = Calendar.getInstance();
        int year = calendar.get(Calendar.YEAR);
        int month = calendar.get(Calendar.MONTH);
        int day = calendar.get(Calendar.DAY_OF_MONTH);

        DatePickerDialog datePickerDialog = new DatePickerDialog(this, (view, selectedYear, selectedMonth, selectedDay) -> {
            String selectedDate = String.format(Locale.getDefault(), "%04d-%02d-%02d", selectedYear, selectedMonth + 1, selectedDay);
            dateField.setText(selectedDate);
        }, year, month, day);
        datePickerDialog.show();
    }

    private void showTimePicker(final EditText timeField) {
        final Calendar calendar = Calendar.getInstance();
        int hour = calendar.get(Calendar.HOUR_OF_DAY);
        int minute = calendar.get(Calendar.MINUTE);

        TimePickerDialog timePickerDialog = new TimePickerDialog(this, (view, selectedHour, selectedMinute) -> {
            String selectedTime = String.format(Locale.getDefault(), "%02d:%02d", selectedHour, selectedMinute);
            timeField.setText(selectedTime);
        }, hour, minute, true);
        timePickerDialog.show();
    }

    private void setMedicineReminder() {
        String medicineName = etMedicineName.getText().toString();
        String purpose = etPurpose.getText().toString();
        String date = etDate.getText().toString();
        String time = etTime.getText().toString();
        String expiration = etExpiration.getText().toString();

        // Convert selectedDays list to a comma-separated string
        String daysToTake = String.join(", ", selectedDays);

        // Determine if it's "everyday"
        boolean isEveryday = selectedDays.isEmpty() || selectedDays.size() == 7;

        // Determine frequency
        int frequencyHours = 0;
        String selectedFrequency = (String) spinnerFrequency.getSelectedItem();
        if (selectedFrequency.equals("Custom")) {
            String customFrequencyStr = etCustomFrequency.getText().toString().trim();
            frequencyHours = customFrequencyStr.isEmpty() ? 0 : Integer.parseInt(customFrequencyStr);
        } else {
            frequencyHours = Integer.parseInt(selectedFrequency.split(" ")[0]); // Extract number from "X Hours"
        }

        // Insert medicine with isEveryday boolean parameter
        long id = databaseHelper.insertMedicine(currentUserId, medicineName, purpose, date, time, expiration, daysToTake, isEveryday, frequencyHours);
        if (id != -1) {
            setAlarm(date, time, medicineName, frequencyHours);
            Toast.makeText(this, "Reminder set for " + medicineName, Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(this, "Error setting reminder", Toast.LENGTH_SHORT).show();
        }
    }


    private void setAlarm(String date, String time, String medicineName, int frequencyHours) {
        Calendar calendar = Calendar.getInstance();
        String[] dateParts = date.split("-");
        String[] timeParts = time.split(":");
        calendar.set(Calendar.YEAR, Integer.parseInt(dateParts[0]));
        calendar.set(Calendar.MONTH, Integer.parseInt(dateParts[1]) - 1); // Months are 0-based
        calendar.set(Calendar.DAY_OF_MONTH, Integer.parseInt(dateParts[2]));
        calendar.set(Calendar.HOUR_OF_DAY, Integer.parseInt(timeParts[0]));
        calendar.set(Calendar.MINUTE, Integer.parseInt(timeParts[1]));
        calendar.set(Calendar.SECOND, 0);

        AlarmManager alarmManager = (AlarmManager) getSystemService(Context.ALARM_SERVICE);
        Intent intent = new Intent(this, AlarmReceiver.class);
        intent.putExtra("medicineName", medicineName);
        PendingIntent pendingIntent = PendingIntent.getBroadcast(this, 0, intent, PendingIntent.FLAG_UPDATE_CURRENT);

        alarmManager.set(AlarmManager.RTC_WAKEUP, calendar.getTimeInMillis(), pendingIntent);

        // Set subsequent alarms based on frequency (if applicable)
        if (frequencyHours > 0) {
            long intervalMillis = frequencyHours * 60 * 60 * 1000; // Convert hours to milliseconds
            alarmManager.setRepeating(AlarmManager.RTC_WAKEUP, calendar.getTimeInMillis() + intervalMillis, intervalMillis, pendingIntent);
        }
    }
}
