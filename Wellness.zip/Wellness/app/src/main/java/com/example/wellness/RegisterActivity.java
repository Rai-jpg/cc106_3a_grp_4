package com.example.wellness;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class RegisterActivity extends AppCompatActivity {

    private DBHelper dbHelper;
    private EditText etName, etEmail, etPassword, etAge, etPrescription;
    private Button btnRegister;
    private ImageButton btnMale, btnFemale;
    private String selectedGender = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        dbHelper = new DBHelper(this);
        etName = findViewById(R.id.editTextName);
        etEmail = findViewById(R.id.editTextEmail);
        etPassword = findViewById(R.id.editTextPassword);
        etAge = findViewById(R.id.editTextAge);
        etPrescription = findViewById(R.id.editTextPrescription);
        btnRegister = findViewById(R.id.btnRegister);
        btnMale = findViewById(R.id.btnMale);
        btnFemale = findViewById(R.id.btnFemale);

        btnRegister.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                registerUser();
            }
        });

        btnMale.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                selectedGender = "Male";
                btnMale.setBackgroundColor(getResources().getColor(R.color.blue)); // Change color on selection
                btnFemale.setBackgroundColor(getResources().getColor(android.R.color.transparent)); // Reset other button
            }
        });

        btnFemale.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                selectedGender = "Female";
                btnFemale.setBackgroundColor(getResources().getColor(R.color.pink)); // Change color on selection
                btnMale.setBackgroundColor(getResources().getColor(android.R.color.transparent)); // Reset other button
            }
        });

        TextView tvLogin = findViewById(R.id.tvLogin);
        tvLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(RegisterActivity.this, LoginActivity.class);
                startActivity(intent);
            }
        });
    }

    private void registerUser() {
        String name = etName.getText().toString().trim();
        String email = etEmail.getText().toString().trim();
        String password = etPassword.getText().toString().trim();  // Keep this one
        int age;

        try {
            age = Integer.parseInt(etAge.getText().toString().trim());
        } catch (NumberFormatException e) {
            Toast.makeText(this, "Please enter a valid age", Toast.LENGTH_SHORT).show();
            return;
        }

        String prescription = etPrescription.getText().toString().trim();

        if (name.isEmpty() || email.isEmpty() || password.isEmpty() || age <= 0 || selectedGender.isEmpty()) {
            Toast.makeText(this, "Please fill in all fields", Toast.LENGTH_SHORT).show();
            return;
        }

        try {
            // The password is already captured, no need to redefine it
            Log.d("RegisterDebug", "Password: " + password);  // Debugging log

            // Insert user into database
            long id = dbHelper.insertUser(name, age, selectedGender, email, password, prescription);

            if (id > 0) {
                Toast.makeText(this, "Registration successful", Toast.LENGTH_SHORT).show();
                startActivity(new Intent(RegisterActivity.this, LoginActivity.class));
                finish();
            } else {
                Toast.makeText(this, "Registration failed. Email may already be in use.", Toast.LENGTH_SHORT).show();
            }
        } catch (Exception e) {
            Log.e("RegisterDebug", "Error during registration: " + e.getMessage());
            Toast.makeText(this, "Error during registration.", Toast.LENGTH_SHORT).show();
        }
    }

}
