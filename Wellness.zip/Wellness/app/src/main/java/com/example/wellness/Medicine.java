package com.example.wellness;

public class Medicine {
    private long id;
    private String name;
    private String purpose;
    private String date;
    private String time;
    private String expiration;
    private long userId;
    private String daysToTake;
    private boolean isEveryday;
    private int frequencyHours;

    // Constructor
    public Medicine(long id, String name, String purpose, String date, String time, String expiration, long userId, String daysToTake, boolean isEveryday, int frequencyHours) {
        this.id = id;
        this.name = name;
        this.purpose = purpose;
        this.date = date;
        this.time = time;
        this.expiration = expiration;
        this.userId = userId;
        this.daysToTake = daysToTake;
        this.isEveryday = isEveryday;
        this.frequencyHours = frequencyHours;
    }

    // Getters for each field
    public long getId() { return id; }

    public String getName() { return name; }

    public String getPurpose() { return purpose; }

    public String getDate() { return date; }

    public String getTime() { return time; }

    public String getExpiration() { return expiration; }

    public long getUserId() { return userId; }

    public String getDaysToTake() { return daysToTake; }

    public boolean isEveryday() { return isEveryday; }

    public int getFrequencyHours() { return frequencyHours; }
}
