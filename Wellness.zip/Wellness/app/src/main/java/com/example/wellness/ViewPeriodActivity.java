package com.example.wellness;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.ListView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.util.List;

public class ViewPeriodActivity extends AppCompatActivity {

    private DBHelper dbHelper;
    private ListView lvPeriods;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_period);

        dbHelper = new DBHelper(this);
        lvPeriods = findViewById(R.id.lvPeriods);

        loadPeriods();
    }

    private void loadPeriods() {
        long userId = getUserId();

        if (userId != -1) {
            List<MenstrualPeriod> periods = dbHelper.getPeriodsForUser(userId);

            if (periods.isEmpty()) {
                Toast.makeText(this, "No periods found", Toast.LENGTH_SHORT).show();
            } else {
                PeriodAdapter adapter = new PeriodAdapter(this, periods);
                lvPeriods.setAdapter(adapter);
            }
        } else {
            Toast.makeText(this, "User not found", Toast.LENGTH_SHORT).show();
        }
    }

    private long getUserId() {
        SharedPreferences sharedPreferences = getSharedPreferences("user_session", MODE_PRIVATE);
        return sharedPreferences.getLong("user_id", -1);
    }
}
