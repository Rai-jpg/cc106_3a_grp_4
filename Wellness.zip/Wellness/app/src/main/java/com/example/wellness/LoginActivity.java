package com.example.wellness;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class LoginActivity extends AppCompatActivity {

    private DBHelper dbHelper;
    private EditText etEmail, etPassword;
    private Button btnLogin;
    private TextView tvRegister; // TextView to navigate to RegisterActivity

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        // Initialize DBHelper and UI components
        dbHelper = new DBHelper(this);
        etEmail = findViewById(R.id.editTextEmail);
        etPassword = findViewById(R.id.editTextPassword);
        btnLogin = findViewById(R.id.btnLogin);
        tvRegister = findViewById(R.id.tvRegister); // Initialize the TextView

        // Set onClickListener for Login button
        btnLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                loginUser(); // Call method to handle login logic
            }
        });

        // Set onClickListener for Register TextView to navigate to RegisterActivity
        tvRegister.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(LoginActivity.this, RegisterActivity.class));
            }
        });
    }

    private void loginUser() {
        String email = etEmail.getText().toString().trim();
        String password = etPassword.getText().toString().trim();

        if (email.isEmpty() || password.isEmpty()) {
            Toast.makeText(this, "Please enter email and password", Toast.LENGTH_SHORT).show();
            return;
        }

        Log.d("LoginActivity", "Attempting login with email: " + email + " and password: " + password);

        try {
            if (dbHelper.checkUser(email, password)) {
                long userId = dbHelper.getUserIdByEmail(email);
                Log.d("LoginActivity", "Login successful. User ID: " + userId);

                SharedPreferences sharedPreferences = getSharedPreferences("user_session", MODE_PRIVATE);
                SharedPreferences.Editor editor = sharedPreferences.edit();
                editor.putLong("user_id", userId);
                editor.apply();

                startActivity(new Intent(LoginActivity.this, HomeActivity.class));
                finish();
            } else {
                Toast.makeText(this, "Invalid email or password", Toast.LENGTH_SHORT).show();
                Log.d("LoginActivity", "Invalid credentials for email: " + email);
            }
        } catch (Exception e) {
            Log.e("LoginActivity", "Error during login: " + e.getMessage());
            Toast.makeText(this, "Error during login. Please try again.", Toast.LENGTH_SHORT).show();
        }
    }


}