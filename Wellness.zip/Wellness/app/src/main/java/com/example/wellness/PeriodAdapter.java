package com.example.wellness;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import java.util.List;

public class PeriodAdapter extends ArrayAdapter<MenstrualPeriod> {
    private Context context;
    private List<MenstrualPeriod> periods;

    public PeriodAdapter(Context context, List<MenstrualPeriod> periods) {
        super(context, 0, periods);
        this.context = context;
        this.periods = periods;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        if (convertView == null) {
            convertView = LayoutInflater.from(context).inflate(R.layout.item_period, parent, false);
        }

        MenstrualPeriod period = periods.get(position);

        TextView startDateTextView = convertView.findViewById(R.id.start_date_text_view);
        TextView cycleLengthTextView = convertView.findViewById(R.id.cycle_length_text_view);
        TextView nextPeriodTextView = convertView.findViewById(R.id.next_period_text_view); // Update layout with this ID

        startDateTextView.setText("Start Date: " + period.getStartDate());
        cycleLengthTextView.setText("Cycle Length: " + period.getCycleLength() + " days");
        nextPeriodTextView.setText("Next Period: " + period.getNextPeriodDate());

        return convertView;
    }
}
