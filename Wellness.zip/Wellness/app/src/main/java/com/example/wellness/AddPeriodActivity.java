package com.example.wellness;

import android.app.DatePickerDialog;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Locale;

public class AddPeriodActivity extends AppCompatActivity {

    private EditText editTextStartDate, editTextCycleLength, editTextNextPeriod;
    private Button buttonAddPeriod;
    private DBHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_period);

        // Initialize views
        editTextStartDate = findViewById(R.id.etStartDate);
        editTextCycleLength = findViewById(R.id.etCycleLength);
        editTextNextPeriod = findViewById(R.id.etNextPeriod);
        buttonAddPeriod = findViewById(R.id.iconAddPeriod);

        dbHelper = new DBHelper(this);

        // Set up date picker for start date
        editTextStartDate.setOnClickListener(v -> showDatePickerDialog());

        // Add period and calculate the next period
        buttonAddPeriod.setOnClickListener(v -> addPeriod());
    }

    private void showDatePickerDialog() {
        Calendar calendar = Calendar.getInstance();
        int year = calendar.get(Calendar.YEAR);
        int month = calendar.get(Calendar.MONTH);
        int day = calendar.get(Calendar.DAY_OF_MONTH);

        DatePickerDialog datePickerDialog = new DatePickerDialog(this, (view, year1, month1, dayOfMonth) -> {
            String selectedDate = String.format(Locale.getDefault(), "%04d-%02d-%02d", year1, month1 + 1, dayOfMonth);
            editTextStartDate.setText(selectedDate);
        }, year, month, day);

        datePickerDialog.show();
    }

    private void addPeriod() {
        String startDate = editTextStartDate.getText().toString().trim();
        String cycleLengthStr = editTextCycleLength.getText().toString().trim();

        if (startDate.isEmpty() || cycleLengthStr.isEmpty()) {
            Toast.makeText(this, "Please fill all fields", Toast.LENGTH_SHORT).show();
            return;
        }

        int cycleLength;
        try {
            cycleLength = Integer.parseInt(cycleLengthStr);
        } catch (NumberFormatException e) {
            Toast.makeText(this, "Invalid cycle length", Toast.LENGTH_SHORT).show();
            return;
        }

        // Get the user ID from SharedPreferences
        SharedPreferences sharedPreferences = getSharedPreferences("user_session", MODE_PRIVATE);
        long userId = sharedPreferences.getLong("user_id", -1);

        if (userId == -1) {
            Toast.makeText(this, "User ID not found", Toast.LENGTH_SHORT).show();
            return;
        }

        // Insert the period into the database
        long insertedId = dbHelper.insertPeriod(userId, startDate, cycleLength);

        if (insertedId == -1) {
            Toast.makeText(this, "Failed to add period", Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(this, "Period added successfully!", Toast.LENGTH_SHORT).show();
            finish(); // Close the activity and return to the home screen
        }
    }


    private String calculateNextPeriod(String startDate, int cycleLength) {
        try {
            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault());
            Calendar calendar = Calendar.getInstance();
            calendar.setTime(sdf.parse(startDate));

            calendar.add(Calendar.DAY_OF_MONTH, cycleLength);
            return sdf.format(calendar.getTime());
        } catch (Exception e) {
            e.printStackTrace();
            return "Invalid date";
        }
    }
}
