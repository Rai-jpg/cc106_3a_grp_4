package com.example.wellness;

import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.os.Bundle;
import android.util.Log;
import android.view.MenuItem;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.drawerlayout.widget.DrawerLayout;
import com.google.android.material.navigation.NavigationView;

public class ViewUserInfoActivity extends AppCompatActivity implements NavigationView.OnNavigationItemSelectedListener {

    private TextView tvName, tvEmail, tvAge, tvSex, tvPassword;
    private ImageView btnTogglePassword;
    private boolean isPasswordVisible = false;
    private DrawerLayout drawerLayout;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_user_info);

        // Initialize the DrawerLayout and Toolbar
        drawerLayout = findViewById(R.id.drawer_layout);
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        // Set up the Drawer Toggle for opening and closing the drawer
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(
                this, drawerLayout, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawerLayout.addDrawerListener(toggle);
        toggle.syncState();

        // Initialize NavigationView and set up the listener
        NavigationView navigationView = findViewById(R.id.navigationView);
        navigationView.setNavigationItemSelectedListener(this);

        // Initialize views
        tvName = findViewById(R.id.tvName);
        tvEmail = findViewById(R.id.tvEmail);
        tvAge = findViewById(R.id.tvAge);
        tvSex = findViewById(R.id.tvSex);
        tvPassword = findViewById(R.id.tvPassword);
        btnTogglePassword = findViewById(R.id.btnTogglePassword);

        // Retrieve the logged-in user ID from SharedPreferences
        SharedPreferences sharedPreferences = getSharedPreferences("user_session", MODE_PRIVATE);
        long userId = sharedPreferences.getLong("user_id", -1);

        if (userId != -1) {
            // Fetch user data from the database
            DBHelper dbHelper = new DBHelper(this);
            Cursor cursor = dbHelper.getUserInfo(userId);

            if (cursor != null && cursor.moveToFirst()) {
                // Retrieve and set user information
                String name = cursor.getString(cursor.getColumnIndexOrThrow(DBHelper.USER_NAME));
                String email = cursor.getString(cursor.getColumnIndexOrThrow(DBHelper.USER_EMAIL));
                int age = cursor.getInt(cursor.getColumnIndexOrThrow(DBHelper.USER_AGE));
                String sex = cursor.getString(cursor.getColumnIndexOrThrow(DBHelper.USER_SEX));
                String password = cursor.getString(cursor.getColumnIndexOrThrow(DBHelper.USER_PASSWORD));

                tvName.setText(name);
                tvEmail.setText(email);
                tvAge.setText(String.valueOf(age));
                tvSex.setText(sex);
                tvPassword.setText("********"); // Initially masked, no encryption

                // Set up password visibility toggle
                btnTogglePassword.setOnClickListener(v -> {
                    if (isPasswordVisible) {
                        tvPassword.setText("********");
                        btnTogglePassword.setImageResource(R.drawable.ic_visibility_off);
                    } else {
                        tvPassword.setText(password);  // Display the password directly (no decryption)
                        btnTogglePassword.setImageResource(R.drawable.ic_visibility);
                    }
                    isPasswordVisible = !isPasswordVisible;
                });

                cursor.close(); // Close the cursor after use
            } else {
                Toast.makeText(this, "User data not found", Toast.LENGTH_SHORT).show();
            }
        } else {
            Toast.makeText(this, "No user logged in", Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem item) {
        int itemId = item.getItemId();

        if (itemId == R.id.dashboard) {
            startActivity(new Intent(this, HomeActivity.class));
        }else if (itemId == R.id.change_password) {
            startActivity(new Intent(this, ChangePasswordActivity.class));
        } else if (itemId == R.id.view_user_info) {
            startActivity(new Intent(this, ViewUserInfoActivity.class));
        } else if (itemId == R.id.delete_account) {
            new AlertDialog.Builder(this)
                    .setTitle("Delete Account")
                    .setMessage("Are you sure you want to delete your account? This action cannot be undone.")
                    .setPositiveButton("Yes", (dialog, which) -> deleteAccount())
                    .setNegativeButton("No", null)
                    .show();
        } else if (itemId == R.id.logout) {
            // Clear user session and navigate to login screen
            SharedPreferences sharedPreferences = getSharedPreferences("user_session", MODE_PRIVATE);
            sharedPreferences.edit().clear().apply(); // Clear session data
            Toast.makeText(this, "Logging out...", Toast.LENGTH_SHORT).show();
            startActivity(new Intent(this, LoginActivity.class));
            finish();
        } else {
            Toast.makeText(this, "Unknown option selected.", Toast.LENGTH_SHORT).show();
        }

        drawerLayout.closeDrawers();
        return true;
    }
    private void deleteAccount() {
        SharedPreferences sharedPreferences = getSharedPreferences("user_session", MODE_PRIVATE);
        long userId = sharedPreferences.getLong("user_id", -1);
        if (userId != -1) {
            DBHelper dbHelper = new DBHelper(this);
            if (dbHelper.deleteUser(userId)) {
                sharedPreferences.edit().clear().apply();
                Toast.makeText(this, "Account deleted successfully.", Toast.LENGTH_SHORT).show();
                startActivity(new Intent(this, LoginActivity.class));
                finish();
            } else {
                Toast.makeText(this, "Failed to delete account.", Toast.LENGTH_SHORT).show();
            }
        }

    }
}
