package com.example.wellness;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.widget.Button;
import android.widget.ListView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.util.List;

public class ViewMedicinesActivity extends AppCompatActivity {

    private DBHelper dbHelper;
    private ListView lvMedicines;
    private Button btnAddMedicine;
    private static final String TAG = "ViewMedicinesActivity";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_medicine);

        dbHelper = new DBHelper(this);
        lvMedicines = findViewById(R.id.lvMedicines);
        btnAddMedicine = findViewById(R.id.btnAddMedicine);

        loadMedicines();

        // Set click listener for "Add New Medicine" button
        btnAddMedicine.setOnClickListener(v -> {
            Intent intent = new Intent(ViewMedicinesActivity.this, AddMedicineActivity.class);
            startActivity(intent);
        });
    }

    public void loadMedicines() {
        long userId = getUserId(); // Get the logged-in user's ID from SharedPreferences
        if (userId != -1) {
            try {
                List<Medicine> medicines = dbHelper.getMedicinesForUser(userId);
                if (medicines != null && !medicines.isEmpty()) {
                    MedicineAdapter adapter = new MedicineAdapter(this, medicines);
                    lvMedicines.setAdapter(adapter);
                } else {
                    // Handle the case where no medicines are found
                    Toast.makeText(this, "No medicines found", Toast.LENGTH_SHORT).show();
                }
            } catch (Exception e) {
                Log.e(TAG, "Error loading medicines", e);
                Toast.makeText(this, "Error loading medicines", Toast.LENGTH_SHORT).show();
            }
        } else {
            // Handle the case where the user ID is not found
            Toast.makeText(this, "User not found", Toast.LENGTH_SHORT).show();
        }
    }

    private long getUserId() {
        // Retrieve the currently logged-in user's ID from SharedPreferences
        SharedPreferences sharedPreferences = getSharedPreferences("user_session", MODE_PRIVATE);
        return sharedPreferences.getLong("user_id", -1); // -1 is the default value if no ID is found
    }
}
