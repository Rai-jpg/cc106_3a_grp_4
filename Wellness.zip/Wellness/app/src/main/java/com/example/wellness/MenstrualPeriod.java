package com.example.wellness;

public class MenstrualPeriod {
    private long id;
    private long userId;
    private String startDate;
    private int cycleLength;
    private String nextPeriodDate; // Added field for next period date

    public MenstrualPeriod(long id, long userId, String startDate, int cycleLength) {
        this.id = id;
        this.userId = userId;
        this.startDate = startDate;
        this.cycleLength = cycleLength;
    }

    public long getId() {
        return id;
    }

    public long getUserId() {
        return userId;
    }

    public String getStartDate() {
        return startDate;
    }

    public int getCycleLength() {
        return cycleLength;
    }

    public String getNextPeriodDate() {
        return nextPeriodDate;
    }

    public void setNextPeriodDate(String nextPeriodDate) {
        this.nextPeriodDate = nextPeriodDate;
    }
}
