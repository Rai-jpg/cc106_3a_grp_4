package com.example.wellness;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.List;

public class MedicineAdapter extends ArrayAdapter<Medicine> {

    private Context context;
    private List<Medicine> medicines;

    public MedicineAdapter(Context context, List<Medicine> medicines) {
        super(context, 0, medicines);
        this.context = context;
        this.medicines = medicines;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        if (convertView == null) {
            convertView = LayoutInflater.from(getContext()).inflate(R.layout.medicine_item, parent, false);
        }

        Medicine medicine = getItem(position);

        // Bind the data to the respective TextViews
        TextView tvMedicineName = convertView.findViewById(R.id.tvMedicineName);
        TextView tvPurpose = convertView.findViewById(R.id.tvPurpose);
        TextView tvExpiration = convertView.findViewById(R.id.tvExpiration);
        TextView tvDate = convertView.findViewById(R.id.tvDate);
        TextView tvTime = convertView.findViewById(R.id.tvTime);
        ImageView btnDeleteMedicine = convertView.findViewById(R.id.btnDeleteMedicine); // Delete Button

        // Set the data for the medicine row
        tvMedicineName.setText(medicine.getName());
        tvPurpose.setText(medicine.getPurpose()); // Ensure the purpose is being set correctly
        tvExpiration.setText("Expires on: " + medicine.getExpiration());
        tvDate.setText("Date: " + medicine.getDate());
        tvTime.setText("Time: " + medicine.getTime());

        // Handle Delete Button Click
        btnDeleteMedicine.setOnClickListener(v -> {
            // Call delete method on the medicine
            deleteMedicine(medicine);
        });

        return convertView;
    }

    private void deleteMedicine(Medicine medicine) {
        // Deleting the medicine from the database
        DBHelper dbHelper = new DBHelper(context);
        dbHelper.deleteMedicine(medicine.getId());

        // Show a toast
        Toast.makeText(context, "Medicine deleted successfully", Toast.LENGTH_SHORT).show();

        // Notify the activity to refresh the list
        if (context instanceof ViewMedicinesActivity) {
            ((ViewMedicinesActivity) context).loadMedicines(); // Call loadMedicines() from the activity
        }
    }
}
