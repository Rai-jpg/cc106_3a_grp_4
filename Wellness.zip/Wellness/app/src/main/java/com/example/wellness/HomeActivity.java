package com.example.wellness;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.MenuItem;
import android.widget.ImageView;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.drawerlayout.widget.DrawerLayout;
import com.google.android.material.navigation.NavigationView;

public class HomeActivity extends AppCompatActivity implements NavigationView.OnNavigationItemSelectedListener {

    private ImageView btnAddMedicine, btnViewMedicines, btnAddPeriod, btnViewPeriods, logoImageView;
    private long userId;
    private DrawerLayout drawerLayout;

    @SuppressLint("NonConstantResourceId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

        // Initialize Toolbar
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        // Initialize DrawerLayout and set up toggle with toolbar
        drawerLayout = findViewById(R.id.drawer_layout);
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(
                this, drawerLayout, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawerLayout.addDrawerListener(toggle);
        toggle.syncState();

        // Initialize NavigationView and set up listener
        NavigationView navigationView = findViewById(R.id.navigationView);
        navigationView.setNavigationItemSelectedListener(this);

        // Initialize ImageView buttons
        btnAddMedicine = findViewById(R.id.iconAddMedicine);
        btnViewMedicines = findViewById(R.id.iconViewMedicines);
        btnAddPeriod = findViewById(R.id.iconAddPeriod);
        btnViewPeriods = findViewById(R.id.iconViewPeriods);

        // Retrieve user ID from SharedPreferences
        SharedPreferences sharedPreferences = getSharedPreferences("UserPrefs", MODE_PRIVATE);
        userId = sharedPreferences.getLong("user_id", -1);

        if (userId == -1) {
            Toast.makeText(this, "Invalid user ID", Toast.LENGTH_SHORT).show();
            finish();
            return;
        }

        // Set up button click listeners
        btnAddMedicine.setOnClickListener(v -> {
            Intent intent = new Intent(HomeActivity.this, AddMedicineActivity.class);
            intent.putExtra("USER_ID", userId);
            startActivity(intent);
        });

        btnViewMedicines.setOnClickListener(v -> {
            Intent intent = new Intent(HomeActivity.this, ViewMedicinesActivity.class);
            intent.putExtra("USER_ID", userId);
            startActivity(intent);
        });

        btnAddPeriod.setOnClickListener(v -> {
            Intent intent = new Intent(HomeActivity.this, AddPeriodActivity.class);
            intent.putExtra("USER_ID", userId);
            startActivity(intent);
        });

        btnViewPeriods.setOnClickListener(v -> {
            Intent intent = new Intent(HomeActivity.this, ViewPeriodActivity.class);
            intent.putExtra("USER_ID", userId);
            startActivity(intent);
        });
    }

    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem item) {
        int itemId = item.getItemId();

        if (itemId == R.id.dashboard) {
            startActivity(new Intent(this, HomeActivity.class));
        } else if (itemId == R.id.change_password) {
            startActivity(new Intent(this, ChangePasswordActivity.class));
        } else if (itemId == R.id.view_user_info) {
            startActivity(new Intent(this, ViewUserInfoActivity.class));
        } else if (itemId == R.id.delete_account) {
            new AlertDialog.Builder(this)
                    .setTitle("Delete Account")
                    .setMessage("Are you sure you want to delete your account? This action cannot be undone.")
                    .setPositiveButton("Yes", (dialog, which) -> deleteAccount())
                    .setNegativeButton("No", null)
                    .show();
        } else if (itemId == R.id.logout) {
            // Clear user session and navigate to login screen
            SharedPreferences sharedPreferences = getSharedPreferences("user_session", MODE_PRIVATE);
            sharedPreferences.edit().clear().apply(); // Clear session data
            Toast.makeText(this, "Logging out...", Toast.LENGTH_SHORT).show();
            startActivity(new Intent(this, LoginActivity.class));
            finish();
        } else {
            Toast.makeText(this, "Unknown option selected.", Toast.LENGTH_SHORT).show();
        }

        drawerLayout.closeDrawers();
        return true;
    }



    private void deleteAccount() {
        SharedPreferences sharedPreferences = getSharedPreferences("user_session", MODE_PRIVATE);
        long userId = sharedPreferences.getLong("user_id", -1);
        if (userId != -1) {
            DBHelper dbHelper = new DBHelper(this);
            if (dbHelper.deleteUser(userId)) {
                sharedPreferences.edit().clear().apply();
                Toast.makeText(this, "Account deleted successfully.", Toast.LENGTH_SHORT).show();
                startActivity(new Intent(this, LoginActivity.class));
                finish();
            } else {
                Toast.makeText(this, "Failed to delete account.", Toast.LENGTH_SHORT).show();
            }
        }
    }
}
