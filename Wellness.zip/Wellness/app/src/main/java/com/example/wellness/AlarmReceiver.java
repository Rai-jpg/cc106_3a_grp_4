package com.example.wellness;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.app.NotificationManager;
import android.app.NotificationChannel;
import android.app.PendingIntent;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Build;
import android.util.Log;
import androidx.core.app.NotificationCompat;

public class AlarmReceiver extends BroadcastReceiver {
    private MediaPlayer mediaPlayer;

    @Override
    public void onReceive(Context context, Intent intent) {
        String medicineName = intent.getStringExtra("medicineName");
        String purpose = intent.getStringExtra("purpose");
        String expiration = intent.getStringExtra("expiration");
        String type = intent.getStringExtra("type");

        Log.d("AlarmReceiver", "Alarm triggered: MedicineName=" + medicineName + ", Type=" + type);

        if (type == null) {
            Log.w("AlarmReceiver", "Type is null; setting to default 'medicine_reminder'");
            type = "medicine_reminder";
        }

        // Play sound
        playSound(context, type);

        // Create notification
        createNotification(context, medicineName, purpose, expiration, type);
    }

    private void playSound(Context context, String type) {
        int soundResId = "expiration_reminder".equals(type) ? R.raw.sound_alarm : R.raw.notif;
        mediaPlayer = MediaPlayer.create(context, soundResId);
        if (mediaPlayer != null) {
            mediaPlayer.setOnCompletionListener(MediaPlayer::release);
            mediaPlayer.start();
        } else {
            Log.e("AlarmReceiver", "Failed to play sound.");
        }
    }

    private void createNotification(Context context, String medicineName, String purpose, String expiration, String type) {
        NotificationManager notificationManager = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
        String channelId = "medicine_reminder_channel";

        // Create notification channel for Android O and above
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(channelId, "Medicine Reminder", NotificationManager.IMPORTANCE_HIGH);
            channel.setDescription("Channel for medicine reminders");
            Uri soundUri = Uri.parse("android.resource://" + context.getPackageName() + "/" +
                    ("expiration_reminder".equals(type) ? R.raw.sound_alarm : R.raw.notif));
            channel.setSound(soundUri, null); // Set custom sound
            notificationManager.createNotificationChannel(channel);
        }

        // Set notification title and content
        String title;
        String content;

        if ("expiration_reminder".equals(type)) {
            title = "Medicine Expired";
            content = "Your medicine \"" + medicineName + "\" has expired.";
        } else if ("medicine_reminder".equals(type)) {
            title = "Medicine Reminder";
            content = "Time to take \"" + medicineName + "\" for \"" + purpose + "\". Expiration date: " + expiration + ".";
        } else {
            title = "Reminder";
            content = "Reminder for \"" + medicineName + "\".";
        }

        Log.d("AlarmReceiver", "Notification Title: " + title);
        Log.d("AlarmReceiver", "Notification Content: " + content);

        // Define the Intent for the notification tap action
        Intent notificationIntent = new Intent(context, HomeActivity.class);
        PendingIntent pendingIntent = PendingIntent.getActivity(context, 0, notificationIntent, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

        // Build and issue the notification
        NotificationCompat.Builder builder = new NotificationCompat.Builder(context, channelId)
                .setSmallIcon(R.drawable.logo)
                .setContentTitle(title)
                .setContentText(content)
                .setPriority(NotificationCompat.PRIORITY_HIGH)
                .setContentIntent(pendingIntent)
                .setAutoCancel(true)
                .setSound(Uri.parse("android.resource://" + context.getPackageName() + "/" +
                        ("expiration_reminder".equals(type) ? R.raw.sound_alarm : R.raw.notif)))
                .setVibrate(new long[]{0, 500, 1000})
                .setDefaults(NotificationCompat.DEFAULT_LIGHTS | NotificationCompat.DEFAULT_VIBRATE);

        int notificationId = type.hashCode() + medicineName.hashCode(); // Unique ID
        notificationManager.notify(notificationId, builder.build());

        Log.d("AlarmReceiver", "Notification created successfully: ID=" + notificationId);
    }

    public void stopSound() {
        if (mediaPlayer != null) {
            mediaPlayer.stop();
            mediaPlayer.release();
            mediaPlayer = null;
        }
    }
}
